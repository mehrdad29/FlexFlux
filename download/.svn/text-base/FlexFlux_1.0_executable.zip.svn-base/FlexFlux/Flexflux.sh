#!/bin/bash

foo=""
for i in `seq 2 $#`
do
    foo="$foo ${!i}" 
done

source config


java -Djava.library.path=$CPLEX_shared_library:$GLPK_shared_library -cp FlexFlux.jar:$CPLEX_JAR:$GLPK_JAR parsebionet.applications.flux.flexflux.Flexflux$1 $foo
